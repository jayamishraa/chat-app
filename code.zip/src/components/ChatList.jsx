import React from 'react'
import Chat from './Chat'

const ChatList = ({messages}) => {
  return (
    <div className='chat-list'>
      {messages.map(text=>{
        return(
          <div className='chat-line'>
            <Chat
              user={text.user}
              message={text.body}
            />
          </div>
        )
      })}
      
    </div>
  )
}

export default ChatList
