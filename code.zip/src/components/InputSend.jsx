import React, { useState } from 'react'

function InputSend({messages, setMessages}) {
    const [newMessage, setNewMessage] = useState('');

    const handleChange = (e) => {
        setNewMessage(e.target.value);
    }

    const handleSend = () => {
        const temp = {
            user: 'person2',
            body: newMessage
        }
        const newArr = [...messages, temp]
        setMessages(newArr)
    }

    return (
        <div className='input'>
        <input 
            type='text' 
            onChange={handleChange}
            value={newMessage}
        />
        <button onClick={()=>handleSend(messages)}>
            <i class="fa-solid fa-paper-plane"></i>
        </button>
        </div>
    )
}

export default InputSend
