import { useState } from "react";
import ChatList from "./components/ChatList";
import Header from "./components/Header";
import InputSend from "./components/InputSend";
import './index.css'

function App() {
  const [messages, setMessages] = useState([
    {
      user: 'person1',
      body: 'test message'
    }, {
      user: 'person1',
      body: 'test message'
    }, {
      user: 'person1',
      body: 'test message'
    }, {
      user: 'person1',
      body: 'test message'
    }, {
      user: 'person1',
      body: 'test message'
    }
  ])

  return (
    <div className="App">
      <Header />
      <ChatList messages={messages} />
      <InputSend 
        messages={messages}
        setMessages={setMessages}
      />
    </div>
  );
}

export default App;
